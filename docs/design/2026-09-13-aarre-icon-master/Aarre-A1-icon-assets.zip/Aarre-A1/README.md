# Aarre · 拾集 A1

这些素材直接从 Figma 可编辑母版导出。

[Figma 成稿与尺规构造](https://www.figma.com/design/u5KlPWzuoMDQBPdO0lP6Mp/DesignThinking?node-id=7387-8839)

- `icon-poppy.svg` 为橙色主版本；`icon-aubergine.svg` 为深色版；`icon-lavender.svg` 为浅紫辅助版。
- `-micro.svg` 是 16–20px 使用的小尺寸版本，间隙略宽。
- `mark-poppy.svg` / `mark-poppy-micro.svg` 是透明背景的单色标志。
- PNG 已按 16、20、24、32、48、64、128px 导出，16 / 20px 使用 Micro，其余使用 Regular。

配色：Poppy #F2633D、Butter #F9F0D5、Aubergine #392B3A、Lavender #D1C9E9。

本次仅交付设计稿与素材，尚未替换插件内图标。
